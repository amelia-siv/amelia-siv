#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

class ItemTracker {
public:
    // Constructor: Loads data from file when an object is created
    ItemTracker();

    // Destructor: Saves data to file when an object is destroyed
    ~ItemTracker();

    // Loads item frequency data from a text file
    void LoadDataFromFile();

    // Saves item frequency data to a text file
    void SaveDataToFile();

    // Searches for a specific item and prints how many times it appears
    void SearchItem();

    // Prints the frequency of each item
    void PrintItemFrequencies();

    // Prints a histogram (visual representation) of item frequencies
    void PrintItemHistograms();

private:
    // A map to store the frequency of each item (key: item name, value: frequency)
    map<string, int> itemFrequency;
};

// Constructor implementation
ItemTracker::ItemTracker() {
    // Load data from file when an object is created
    LoadDataFromFile();
}

// Destructor implementation
ItemTracker::~ItemTracker() {
    // Save data to file when an object is destroyed
    SaveDataToFile();
}

// Method to load data from a file
void ItemTracker::LoadDataFromFile() {
    ifstream inFile("CS210_Project_Three_Input_File.txt"); // Open the input file
    if (!inFile) { // Check if the file was opened successfully
        cerr << "Error opening input file." << endl;
        return; // Exit the method if the file couldn't be opened
    }

    string item;
    while (getline(inFile, item)) { // Read each line (item) from the file
        ++itemFrequency[item]; // Increment the frequency count for the item
    }
    inFile.close(); // Close the input file
}

// Method to save data to a file
void ItemTracker::SaveDataToFile() {
    ofstream outFile("frequency.dat"); // Open the output file
    if (!outFile) { // Check if the file was opened successfully
        cerr << "Error opening output file." << endl;
        return; // Exit the method if the file couldn't be opened
    }

    // Write each item and its frequency to the output file
    for (const auto& entry : itemFrequency) {
        const auto& item = entry.first; // Item name
        const auto& count = entry.second; // Item frequency
        outFile << item << " " << count << endl; // Write the item and its frequency
    }

    outFile.close(); // Close the output file
}

// Method to search for an item and print its frequency
void ItemTracker::SearchItem() {
    string searchItem;
    cout << "Enter item to search for: ";
    getline(cin, searchItem); // Get the item name from the user

    // Use find to check if the item exists in the map
    auto it = itemFrequency.find(searchItem);
    if (it != itemFrequency.end()) { // If the item is found
        cout << searchItem << " appears " << it->second << " times." << endl; // Print the frequency
    }
    else { // If the item is not found
        cout << searchItem << " was not found." << endl; // Print a not found message
    }
}

// Method to print the frequency of each item
void ItemTracker::PrintItemFrequencies() {
    cout << "ITEM FREQUENCIES" << endl;
    for (const auto& entry : itemFrequency) { // Iterate over each item in the map
        const auto& item = entry.first; // Item name
        const auto& count = entry.second; // Item frequency
        cout << item << ": " << count << endl; // Print the item and its frequency
    }
}

// Method to print histograms for each item based on their frequencies
void ItemTracker::PrintItemHistograms() {
    cout << "ITEM HISTOGRAMS" << endl;
    for (const auto& entry : itemFrequency) { // Iterate over each item in the map
        const auto& item = entry.first; // Item name
        const auto& count = entry.second; // Item frequency
        cout << item << " "; // Print the item name
        for (int i = 0; i < count; ++i) { // Print asterisks equal to the frequency count
            cout << "*";
        }
        cout << endl; // Move to the next line after printing the histogram for an item
    }
}

// Main function to interact with the user and manage the menu
int main() {
    ItemTracker tracker; // Create an instance of ItemTracker, which automatically loads data
    int choice;

    do {
        // Display the menu
        cout << "Menu:" << endl;
        cout << "1. Search for an item" << endl;
        cout << "2. Print item frequencies" << endl;
        cout << "3. Print item histograms" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice (1-4): ";
        cin >> choice;
        cin.ignore(); // Ignore the newline character left in the buffer

        // Handle the user's choice
        switch (choice) {
        case 1:
            tracker.SearchItem(); // Search for an item
            break;
        case 2:
            tracker.PrintItemFrequencies(); // Print item frequencies
            break;
        case 3:
            tracker.PrintItemHistograms(); // Print item histograms
            break;
        case 4:
            cout << "Exiting program." << endl; // Exit the program
            break;
        default:
            cout << "Invalid choice, please try again." << endl; // Handle invalid input
            break;
        }
    } while (choice != 4); // Repeat the menu until the user chooses to exit

    return 0; // End of the program
}

